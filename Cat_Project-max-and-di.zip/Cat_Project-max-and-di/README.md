# Cat_Project

## แยกโฟลเดอร์ตามนามสกุลไฟล์ .html .css .js
```
ใช้กับอันไหนก็ตั้งชื่อให้เหมือนกัน เช่น index.html | index.css | index.js
css ของ index.html คือ index.css
script ของ index.html คือ index.js
```
## แยก Branch ตามหน้าที่ที่ตัวเองรับผิดชอบเลย สร้าง Branch เป็นของตัวเอง
``` 
ใครเขียนของใครก็เลือก branch ให้ถูกด้วยนะเพื่อน
fontend เวลาเขียน ให้เขียน Mockup ข้อมูลขึ้นมาเองก่อนเลย เด่ว db ตามมาใส่ข้อมูลให้ทีหลัง
fontend ใช้ boostarp5 ได้นะ import ตัวอย่างไว้ให้ใน index.html แล้ว
```
 
